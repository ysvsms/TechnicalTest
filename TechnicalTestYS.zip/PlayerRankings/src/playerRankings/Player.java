package playerRankings;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Player implements Comparable<Player>{

	private String playerName;
	private int roundsPlayed;
	private int averageScore;
	private List<Integer> scoreList = new ArrayList<Integer>();
	
	public Player(String playerName, int firstScore) {
		this.playerName = playerName;
		this.scoreList.add(firstScore);
	}
	

	public void setAverageScore(){
		Collections.sort(scoreList);
		int sum = 0;
		for (int i = 0; i < 5; i++) {
			try {
			sum += scoreList.get(i);
			}
			catch (Exception e) {}
		}
		averageScore = sum/5;
	}
	
	public int getRoundsPlayed() {
		this.roundsPlayed = scoreList.size();
		return roundsPlayed;
	}
	
	public int getAverageScore(){
		this.setAverageScore();
		return averageScore;
	}
	
	public int getLowestScore(){
		Collections.sort(scoreList);
		return scoreList.get(0);
	}	
	
	public void addScore(int newScore) {
		scoreList.add(newScore);
	}
	
	public String getPlayerName(){
		return playerName;
	}
	
    //Overriding this method to make the ranking list comparison
	@Override
	public int compareTo(Player p) {
		if (new Integer(getAverageScore()).compareTo(p.getAverageScore()) == 0) {
			return new Integer(getLowestScore()).compareTo(p.getLowestScore());
		}
		else {
			return new Integer(getAverageScore()).compareTo(p.getAverageScore());
		}
	   
	}	
	

}
