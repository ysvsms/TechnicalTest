package playerRankings;
import playerRankings.Player;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class PlayerRankings {

	public static void main(String[] args) {
		File golfScores = new File("src/playerRankings/golf_scores.csv");
		List<Player> playerList = new ArrayList<Player>();
		try{
			BufferedReader reader = new BufferedReader(new FileReader(golfScores));
			String line;
			//ignore first line of csv
			String header = reader.readLine();
			while((line = reader.readLine()) != null){
				String[] data = line.split(",");
				if (playerList.isEmpty() == false) { 
					//check and see if player is in the list of players
					boolean match = false;
					for (int i = 0; i < playerList.size(); i++) {
						//data[0] is "name", data[1] is "score"
						if (data[0].equalsIgnoreCase(playerList.get(i).getPlayerName().toString()))
						{
							//if so, add their score to the individual player's list of scores
							playerList.get(i).addScore(Integer.parseInt(data[1]));
							match = true;
							break;
						}
						}
					//if not, add them to the player list with their first score
					if (match == false) {
						Player golfPlayer = new Player(data[0], Integer.parseInt(data[1]));
						playerList.add(golfPlayer);
						}
					}
				//this is to start the player list with the first player that appears in the csv file
				else {
					Player golfPlayer = new Player(data[0], Integer.parseInt(data[1]));
					playerList.add(golfPlayer);
				}
	
			}
			reader.close();
			}
			catch (IOException e){
				System.out.println("I/O Error");
			}

	Collections.sort(playerList);
	int rank = 0;
	for (int i=0; i < playerList.size();i++) {
		//if any player in the list has <5 rounds played, remove them from the list 
		if (playerList.get(i).getRoundsPlayed() >= 5)
		System.out.println(rank + ":" + playerList.get(i).getPlayerName() + " " + playerList.get(i).getAverageScore());
		rank += 1;
	}
	}

}
