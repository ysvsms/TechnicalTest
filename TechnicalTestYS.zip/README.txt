Question 1 is in the ClosestFarthestPoints Folder.
I ran it from cmd on Windows using these two commands from inside the ClosestFarthestPoints folder.


javac -cp lib/guava-18.0.jar; src/closestFarthestPoints/*.java

java -cp bin;lib/guava-18.0.jar; closestFarthestPoints.ClosestFarthestPoints

--------------------------------------------------------------------------------
Question 2 is in the PlayerRankings Folder.
I ran it using these two commands from inside the PlayerRankings folder.


javac -cp . src/playerRankings/*.java

java -cp bin; playerRankings.PlayerRankings


They should also be able to run in Eclipse. Thank you
