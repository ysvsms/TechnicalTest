package closestFarthestPoints;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import com.google.common.collect.Lists;

//used Guava to partition list
public class ClosestFarthestPoints {
	

	public static void main(String[] args) {
		File aPointsFile = new File("src/a.csv");
		File bPointsFile = new File("src/b.csv");
		List<Point> aPoints = new ArrayList<Point>();
		List<Point> bPoints = new ArrayList<Point>();
		try{
			BufferedReader readerA = new BufferedReader(new FileReader(aPointsFile));
			BufferedReader readerB = new BufferedReader(new FileReader(bPointsFile));
			//ignore first line of csv
			String header = readerA.readLine();
			header = readerB.readLine();
			String line;
			while((line = readerA.readLine()) != null){
				String[] data = line.split(",");
				Point p = new Point(Double.parseDouble(data[0]), Double.parseDouble(data[1]), Integer.parseInt(data[2]));
				aPoints.add(p);
				}
			readerA.close();
			while((line = readerB.readLine()) != null){
				String[] data = line.split(",");
				Point p = new Point(Double.parseDouble(data[0]), Double.parseDouble(data[1]), Integer.parseInt(data[2]));
				bPoints.add(p);
				}
			readerB.close();
			}
		catch (IOException e){
			System.out.println("I/O Error");
			}

		//Sort the lists of points from A and B separately
		Collections.sort(aPoints);
		Collections.sort(bPoints);

		//Points where max distance and min distances were found
		Point maxA = new Point(0,0,0);
		Point maxB = new Point(0,0,0);
		Point minA = new Point(0,0,0);
		Point minB = new Point(0,0,0);
		
		double minDistance = 10.0;
		double maxDistance = 10.0;
		
		//Partition the lists into chunks of 100 and calculate the min "relative" distance (distance but without square root)
		for (List<Point> aPartition : Lists.partition(aPoints, 100)) {
			for  (List<Point> bPartition : Lists.partition(bPoints, 100)) {
				for (int i = 0; i < aPartition.size(); i++) {
					for (int i2 = 0; i2 < bPartition.size(); i2++) {
						//checks if relative distance is less than "minDistance" which starts off at 10.
						if (aPartition.get(i).getRelativeDistance(bPartition.get(i2)) < minDistance){
							minDistance = aPartition.get(i).getRelativeDistance(bPartition.get(i2));
							minA = aPartition.get(i);
							minB = bPartition.get(i2);
							
						}
					}
			}
			}
		}
		System.out.println("The min point from A is (" + minA.x +", " + minA.y +")");
		System.out.println("The min point from B is (" + minB.x +", " + minB.y +")");
		System.out.println("The min distance from A-B is " + minA.getDistance(minB));
		 
		//Reverse one of the partitioned lists so that the points with lower x values get compared with ones with higher x values
		List<List<Point>> backwardsList = new ArrayList<List<Point>>();
		for (List<Point> aPartition : Lists.partition(aPoints, 10)) {
			backwardsList.add(aPartition);
		}
		
		List<List<Point>> reversePartition = Lists.reverse(backwardsList);

		for (List<Point> aPartition : reversePartition) {
			for  (List<Point> bPartition : Lists.partition(bPoints, 10)) {
				for (int i = 0; i < aPartition.size(); i++) {
					for (int i2 = 0; i2 < bPartition.size(); i2++) {
						if (aPartition.get(i).getRelativeDistance(bPartition.get(i2)) > minDistance){
							maxDistance = aPartition.get(i).getRelativeDistance(bPartition.get(i2));
							maxA = aPartition.get(i);
							maxB = bPartition.get(i2);
							
						}
					}
				
			}
			}
		}
		
		System.out.println("The max point from A is (" + maxA.x +", " + maxA.y +")");
		System.out.println("The max point from B is (" + maxB.x +", " + maxB.y +")");
		System.out.println("The max distance from A-B is " + maxA.getDistance(maxB));
}
}