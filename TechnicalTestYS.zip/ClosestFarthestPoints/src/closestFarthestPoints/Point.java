package closestFarthestPoints;

public class Point implements Comparable<Point>{

	public double x;
	public double y;
	public int id;

	public Point(double x, double y, int id) {
		this.x = x;
		this.y = y;
		this.id = id;
	}
	
	public double getDistance(Point p) {
		return Math.sqrt(Math.pow((p.x - this.x),2.0) + Math.pow(p.y - this.y, 2.0));
	}
	
	public double getRelativeDistance(Point p) {
		return Math.pow((p.x - this.x),2.0) + Math.pow(p.y - this.y, 2.0);
	}

	@Override
	public int compareTo(Point p) {
		if (new Double(x).compareTo(p.x) == 0) {
			return new Double(y).compareTo(p.y);
		}
		else
		return new Double(x).compareTo(p.x);
	}
	

}
